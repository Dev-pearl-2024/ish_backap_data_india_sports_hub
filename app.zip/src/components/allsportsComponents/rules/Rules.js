import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const Rules = () => {
  return (
    <View>
      <Text>Rules</Text>
    </View>
  );
};

export default Rules;

const styles = StyleSheet.create({});
