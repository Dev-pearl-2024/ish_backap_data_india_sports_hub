import React, { useEffect, useState } from 'react';
import {
  Dimensions,
  Linking,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Carousel, { Pagination } from 'react-native-snap-carousel';
import CarouselCardItem from './CarouselCardItem';
import { useSelector } from 'react-redux';
import moment from 'moment';
import FootballIcon from '../../assets/icons/football.svg';
import Zomato from '../../assets/icons/zomato.svg';
import { useNavigation } from '@react-navigation/native';
import COLORS from '../../constants/Colors';
import RedHeart from '../../assets/icons/redHeart.svg';
import GrayHeart from '../../assets/icons/grayHeart.svg';
import { Image } from 'react-native';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import iconData from '../../data/sportsDataSmall';
import BannerAdComponent from '../Ads/BannerAdsComponent';
import NativeAdComponent from '../Ads/NativeAdsComponent';
import ScoreCard from '../ScoreCardComponents/ScoreCardFootBall';
import dynamicSize from '../../utils/DynamicSize';
import SmallScoreCard from '../ScoreCardComponents/smallScoreCardFootBall';
import Live from '../../assets/icons/live.svg'
import Scheduled from '../../assets/icons/scheduled.svg'
import Completed from '../../assets/icons/completed.svg'

const SLIDER_WIDTH = Dimensions.get('window').width - 20;
const SLIDER_HEIGHT = Dimensions.get('window').height / 3.9;
const ITEM_WIDTH = Math.round(SLIDER_WIDTH * 0.5);

const SmallCarouselCards = ({ carouselData, authState, setInternationalData }) => {
  const [index, setIndex] = React.useState(0);
  const isCarousel = React.useRef(null);
  const navigation = useNavigation();
  const [accessToken, setAccessToken] = useState(null)
  const [isPremium, setIsPremium] = useState("")

  const getStoreData = async () => {
    let userDataStore = await AsyncStorage.getItem('userData');
    const { accessToken } = JSON.parse(userDataStore)
    setAccessToken(accessToken)
  }

  useEffect(() => {
    getStoreData()
  }, [])

  useEffect(() => {
    const getUserDetails = async () => {
      const userID = await AsyncStorage.getItem('userId');
      try {
        const response = await axios({
          method: 'GET',
          url: `https://prod.indiasportshub.com/users/${userID}`,
        });
        if (response?.data?.message === 'User found successfully') {
          setIsPremium(response.data.existing.isPremiumUser)
        }
        return response.data;
      } catch (error) {
        throw new Error('Failed get User Details', error);
      }
    };
    getUserDetails()

  }, [])


  const handleFav = async (id, fav) => {
    let userId = await AsyncStorage.getItem('userId');
    try {
      let res = await axios({
        method: 'post',
        url: `https://prod.indiasportshub.com/users/myfavorite/${userId}/category/event`,
        data: {
          favoriteItemId: id,
          isAdd: !fav,
        },
      });

      setInternationalData(
        [carouselData?.[0]?.map(item =>
          item._id === id ? { ...item, isFavorite: !item.isFavorite } : item
        )]
      );
    } catch (e) {
      console.log(e);
    }
  };

  const renderVs = item => {
    return <SmallScoreCard item={item} />;
  };

  const renderCarouselItem = ({ item, index }) => {
    const sportsData = iconData?.find(
      icon => icon.name?.toLowerCase() === item.sport?.toLowerCase(),
    );

    return item?.type === 'GOOGLE_AD' ? (
      <TouchableOpacity
        style={[styles.container]}
        key={index}>
        <Text style={{ color: COLORS.black }}>Google Ads</Text>
        <BannerAdComponent />
      </TouchableOpacity>
    ) : (
      <TouchableOpacity
        onPress={() => {
          navigation.navigate('score-view', { sportData: item, isPremiumUser: isPremium });
        }}
        style={[styles.container]}
        key={index}
        activeOpacity={0.9}
      >
        <View style={{ flexDirection: 'row', justifyContent: 'flex-start', width: '100%' }}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              // justifyContent: 'flex-start',
            }}>
            <Image
              src={item?.tournamentsDetails?.icon}
              style={{
                width: dynamicSize(25),
                height: dynamicSize(25),
                objectFit: 'contain'
              }}
            />
            <View style={{ marginHorizontal: 10, width: '80%' }}>
              <Text
                numberOfLines={2}
                style={{ fontSize: dynamicSize(8), fontWeight: '700', color: COLORS.black }}>
                {item?.tournamentName}
              </Text>
              <Text
                style={{ fontSize: dynamicSize(6), color: COLORS.black, width: '100%', marginBottom: "2%" }}
                numberOfLines={1}>
                {item?.category} / {item?.eventGender}
              </Text>
            </View>
          </View>
        </View>
        <View style={{ alignContent: 'center' }}>
          <View
            style={{
              flexDirection: 'row',
              alignSelf: 'center',
              justifyContent: 'space-between',
            }}>
            {renderVs(item)}
          </View>
          <View style={{ flex: 1, justifyContent: 'space-between', marginBottom: "10%" }}>
            <View >
              <Text style={{
                display: 'flex',
                textAlign: 'left',
                position: "absolute",
                fontSize: dynamicSize(8),
                // justifyContent: 'center',
                // alignContent: 'center',
                alignItems: 'center',
                color: COLORS.black
              }}>
                {item?.eventStatus == 'live' ? <Live /> : item?.eventStatus == 'completed' ? <Completed /> : <Scheduled />}
              </Text>
              <Text style={{
                display: 'flex',
                textAlign: 'left',
                position: "absolute",
                fontSize: dynamicSize(8),
                left: "10%",
                fontWeight: 'bold',
                alignItems: 'center',
                color: COLORS.black
              }}>
                {item?.eventStage}
              </Text>
              <Text style={{
                textAlign: 'right',
                width: '100%',
                position: "absolute",
                fontSize: dynamicSize(8),
                color: COLORS.black
              }}
              >
                {moment(item?.startDate).format('DD MMM')} | {item?.startTime}
              </Text>
            </View>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View
      style={{
        flex: 1,
      }}>
      <Carousel
        layout="default"
        layoutCardOffset={'10%'} // Adjust gap between cards
        ref={isCarousel}
        data={carouselData[0]?.filter((it) => it?.type !== 'GOOGLE_AD')}
        renderItem={renderCarouselItem}
        sliderWidth={SLIDER_WIDTH}
        itemWidth={ITEM_WIDTH}
        // onSnapToItem={index => setIndex(index)}
        useScrollView={true}
        loop={true}
        activeSlideAlignment="center" // Align active slide to the start
        inactiveSlideScale={1} // Prevent scaling of inactive slides
        inactiveSlideOpacity={1} // Prevent opacity change of inactive slides
      // autoplay={true} // 🔁 Enables auto slide
      // autoplayInterval={10} // ⏱ Slide every 4 seconds
      // autoplayDelay={1}
      />
    </View>
  );
};

export default SmallCarouselCards;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginVertical: dynamicSize(2),
    paddingHorizontal: dynamicSize(7),
    width: '95%',
    borderRadius: dynamicSize(5),
    backgroundColor: 'white',
    justifyContent: 'center',
    shadowColor: COLORS.grey,
    shadowOffset: {
      width: dynamicSize(0),
      height: dynamicSize(1),
    },
    // paddingTop: dynamicSize(5),
    shadowOpacity: 0.25,
    shadowRadius: dynamicSize(2),
    elevation: 5,
    position: 'relative',
  },
  skeletonContainer: {
    width: '95%',
    borderRadius: dynamicSize(4),
  },
  redDot: {
    width: dynamicSize(10),
    height: dynamicSize(10),
    borderRadius: dynamicSize(50),
    backgroundColor: COLORS.red,
    marginHorizontal: dynamicSize(5),
  },
  liveView: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'flex-start',
    position: 'absolute',
    top: 5,
    right: 5,
  },
  line: {
    width: '50%',
    height: dynamicSize(2),
    backgroundColor: COLORS.secondary,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
    marginVertical: dynamicSize(10),
  },

  containerVs: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  team: {},
  vsIcon: {
    width: dynamicSize(10), // Adjust the width as needed
    height: dynamicSize(50), // Adjust the height as needed
  },
});
