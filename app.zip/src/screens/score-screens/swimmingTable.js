import { View } from 'react-native'

export default function SwimmingTable() {
  return (
    <View>SwimmingTable</View>
  )
}
