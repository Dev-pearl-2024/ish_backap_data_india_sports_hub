import React from 'react'
import {
    View,Text
  } from 'react-native';
const AsianRanking = () => {
  return (
    <View><Text>IndianRanking</Text></View>
  )
}

export default AsianRanking