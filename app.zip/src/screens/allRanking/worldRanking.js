import React from 'react';
import {
    View,Text
  } from 'react-native';

const WorldRanking = () => {
  return (
    <View><Text>IndianRanking</Text></View>
  )
}

export default WorldRanking